#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import serial
import math
import csv
from datetime import datetime

class SerialImuPublisher(Node):
    def __init__(self):
        super().__init__('serial_imu_publisher')
        
        # Create publisher for IMU data - matches plotter subscription topic
        self.publisher_ = self.create_publisher(Imu, '/imu', 10)
        self.setup_csv_recording()
        
        # Debug flag for showing filtered messages (set to True to see what's being ignored)
        self.debug_filtering = False
        
        # Alpha filtering parameters (0 = heavy filtering, 1 = no filtering)
        # Accelerometer: Lower alpha (0.1-0.3) for more smoothing - reduces vibration noise
        # Gyroscope: Higher alpha (0.3-0.7) for less smoothing - preserves quick rotations
        self.alpha_accel = 0.2   # Good for reducing vibration noise on hexapod
        self.alpha_gyro = 0.5    # Preserves rotation dynamics
        
        # You can tune these values:
        # - Decrease alpha_accel (e.g., 0.1) if too much vibration noise
        # - Increase alpha_accel (e.g., 0.3) if orientation response is too slow
        # - Decrease alpha_gyro (e.g., 0.3) if rotation data is too noisy
        # - Increase alpha_gyro (e.g., 0.7) if missing quick rotation changes
        
        # Filtered values storage
        self.filtered_ax = None
        self.filtered_ay = None
        self.filtered_az = None
        self.filtered_gx = None
        self.filtered_gy = None
        self.filtered_gz = None
        
        # Flag to track first reading
        self.first_reading = True
        
        # Initialize serial connection
        try:
            self.serial_port = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
            self.get_logger().info('Serial connection established on /dev/ttyUSB0')
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            return
            
        # Timer to read serial data at 10 Hz
        self.timer = self.create_timer(0.1, self.read_serial_data)
        
        # Initialize variables for orientation estimation
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        
        self.get_logger().info(f'Serial IMU Publisher node started - Alpha filtering enabled (accel: {self.alpha_accel}, gyro: {self.alpha_gyro})')

    def apply_alpha_filter(self, new_ax, new_ay, new_az, new_gx, new_gy, new_gz):
        """
        Apply alpha filtering to IMU data to reduce noise and vibrations.
        Alpha filter: filtered_value = alpha * new_value + (1 - alpha) * old_value
        """
        if self.first_reading:
            # Initialize filter with first reading
            self.filtered_ax = new_ax
            self.filtered_ay = new_ay
            self.filtered_az = new_az
            self.filtered_gx = new_gx
            self.filtered_gy = new_gy
            self.filtered_gz = new_gz
            self.first_reading = False
            return new_ax, new_ay, new_az, new_gx, new_gy, new_gz
        
        # Apply alpha filtering to accelerometer data
        self.filtered_ax = self.alpha_accel * new_ax + (1 - self.alpha_accel) * self.filtered_ax
        self.filtered_ay = self.alpha_accel * new_ay + (1 - self.alpha_accel) * self.filtered_ay
        self.filtered_az = self.alpha_accel * new_az + (1 - self.alpha_accel) * self.filtered_az
        
        # Apply alpha filtering to gyroscope data
        self.filtered_gx = self.alpha_gyro * new_gx + (1 - self.alpha_gyro) * self.filtered_gx
        self.filtered_gy = self.alpha_gyro * new_gy + (1 - self.alpha_gyro) * self.filtered_gy
        self.filtered_gz = self.alpha_gyro * new_gz + (1 - self.alpha_gyro) * self.filtered_gz
        
        return (self.filtered_ax, self.filtered_ay, self.filtered_az, 
                self.filtered_gx, self.filtered_gy, self.filtered_gz)

    def set_alpha_values(self, alpha_accel=None, alpha_gyro=None):
        """
        Dynamically adjust alpha filtering values during runtime.
        Useful for tuning filter performance without restarting the node.
        """
        if alpha_accel is not None:
            self.alpha_accel = max(0.0, min(1.0, alpha_accel))  # Clamp between 0 and 1
            self.get_logger().info(f'Alpha accelerometer updated to: {self.alpha_accel}')
        
        if alpha_gyro is not None:
            self.alpha_gyro = max(0.0, min(1.0, alpha_gyro))  # Clamp between 0 and 1
            self.get_logger().info(f'Alpha gyroscope updated to: {self.alpha_gyro}')

    def estimate_orientation_from_accel(self, ax, ay, az):
        """
        Estimate roll and pitch from accelerometer data.
        This provides basic orientation when no magnetometer/gyro integration is available.
        """
        # Calculate roll and pitch from accelerometer
        # Note: This assumes the accelerometer is measuring gravity when stationary
        roll = math.atan2(ay, math.sqrt(ax*ax + az*az))
        pitch = math.atan2(-ax, math.sqrt(ay*ay + az*az))
        
        # Yaw cannot be determined from accelerometer alone
        yaw = 0.0
        
        return roll, pitch, yaw
    
    def euler_to_quaternion(self, roll, pitch, yaw):
        """
        Convert Euler angles to quaternion.
        """
        # Calculate half angles
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        # Calculate quaternion components
        w = cy * cp * cr + sy * sp * sr
        x = cy * cp * sr - sy * sp * cr
        y = sy * cp * sr + cy * sp * cr
        z = sy * cp * cr - cy * sp * sr
        
        return x, y, z, w

    def read_serial_data(self):
        try:
            # Check if serial port is available
            if not hasattr(self, 'serial_port') or not self.serial_port.is_open:
                return
                
            line = self.serial_port.readline().decode('utf-8').strip()
            
            # Skip empty lines
            if not line:
                return
            
            # ONLY process lines that start with "imu:" - ignore everything else
            if not line.startswith("imu:"):
                # Optional debug logging to see what's being filtered out
                if self.debug_filtering:
                    self.get_logger().debug(f'Filtered out (not IMU data): {line[:50]}...')
                return

            # Parse the IMU serial data
            parts = line.replace("imu: ", "").split(',')
            if len(parts) != 7:
                self.get_logger().warn(f'Invalid IMU data format: expected 7 parts, got {len(parts)}')
                return

            # Extract raw data
            timestamp_ms = int(parts[0])
            raw_ax, raw_ay, raw_az = float(parts[1]), float(parts[2]), float(parts[3])
            raw_gx, raw_gy, raw_gz = float(parts[4]), float(parts[5]), float(parts[6])


            raw_data = (raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz)
            filtered_data = (ax, ay, az, gx, gy, gz)
            self.record_to_csv(timestamp_ms, raw_data)


            # Apply alpha filtering to reduce noise and vibrations
            ax, ay, az, gx, gy, gz = self.apply_alpha_filter(
                raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz
            )

            # Create IMU message
            imu_msg = Imu()
            imu_msg.header.stamp = self.get_clock().now().to_msg()
            imu_msg.header.frame_id = "imu_link"

            # Linear acceleration in m/s^2
            imu_msg.linear_acceleration.x = ax
            imu_msg.linear_acceleration.y = ay
            imu_msg.linear_acceleration.z = az
            
            # Set covariance for linear acceleration
            imu_msg.linear_acceleration_covariance[0] = 0.01  # x variance
            imu_msg.linear_acceleration_covariance[4] = 0.01  # y variance
            imu_msg.linear_acceleration_covariance[8] = 0.01  # z variance

            # Angular velocity in rad/s (convert from deg/s)
            imu_msg.angular_velocity.x = math.radians(gx)
            imu_msg.angular_velocity.y = math.radians(gy)
            imu_msg.angular_velocity.z = math.radians(gz)
            
            # Set covariance for angular velocity
            imu_msg.angular_velocity_covariance[0] = 0.01  # x variance
            imu_msg.angular_velocity_covariance[4] = 0.01  # y variance
            imu_msg.angular_velocity_covariance[8] = 0.01  # z variance

            # Estimate orientation from accelerometer data
            # This provides basic roll/pitch estimation for the plotter
            roll, pitch, yaw = self.estimate_orientation_from_accel(ax, ay, az)
            
            # Convert to quaternion
            qx, qy, qz, qw = self.euler_to_quaternion(roll, pitch, yaw)
            
            # Set orientation quaternion
            imu_msg.orientation.x = qx
            imu_msg.orientation.y = qy
            imu_msg.orientation.z = qz
            imu_msg.orientation.w = qw
            
            # Set orientation covariance (indicating limited accuracy since it's from accel only)
            imu_msg.orientation_covariance[0] = 0.1   # roll variance
            imu_msg.orientation_covariance[4] = 0.1   # pitch variance
            imu_msg.orientation_covariance[8] = 1.0   # yaw variance (high since not measurable from accel)

            # Publish the message
            self.publisher_.publish(imu_msg)
            
            # Debug log (reduce frequency to avoid spam)
            if timestamp_ms % 1000 < 100:  # Log roughly every second
                self.get_logger().info(
                    f'Published IMU data - Filtered Accel: ({ax:.2f}, {ay:.2f}, {az:.2f}), '
                    f'Filtered Gyro: ({gx:.2f}, {gy:.2f}, {gz:.2f}), '
                    f'Orientation: R:{math.degrees(roll):.1f}° P:{math.degrees(pitch):.1f}°'
                )

        except serial.SerialException as e:
            self.get_logger().error(f"Serial communication error: {e}")
        except ValueError as e:
            self.get_logger().warn(f"Failed to parse IMU serial data: {e}")
        except Exception as e:
            self.get_logger().error(f"Unexpected error: {e}")


    def setup_csv_recording(self):
        """Setup CSV file for recording raw IMU data"""
        # Create filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.csv_filename = f"raw_imu_data_{timestamp}.csv"
        
        # Initialize CSV file with headers
        with open(self.csv_filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                'timestamp_ms', 'raw_ax', 'raw_ay', 'raw_az', 
                'raw_gx', 'raw_gy', 'raw_gz',
                'filtered_ax', 'filtered_ay', 'filtered_az',
                'filtered_gx', 'filtered_gy', 'filtered_gz'
            ])

    def record_to_csv(self, timestamp_ms, raw_data):
        """Record raw and filtered data to CSV"""
        raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz = raw_data
        
        
        with open(self.csv_filename, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                timestamp_ms, raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz
            ])

    def destroy_node(self):
        """Clean up resources when node is destroyed."""
        if hasattr(self, 'serial_port') and self.serial_port.is_open:
            self.serial_port.close()
            self.get_logger().info('Serial port closed')
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = SerialImuPublisher()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()